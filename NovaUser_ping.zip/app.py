import os
import urllib.request
import urllib.error
import subprocess
import platform
from flask import Flask, render_template, request, redirect, session, url_for
from datetime import datetime

app = Flask(__name__)
app.secret_key = "dev-key-2025"
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

@app.context_processor
def inject_globals():
    return {
        'app_name': 'NovaUser',
        'current_year': datetime.now().year,
        'current_time': datetime.now().strftime('%Y-%m-%d %H:%M'),
    }

USERS = {
    "admin": {"user_id": 1, "username": "admin", "password": "admin123", "role": "admin", "email": "admin@example.com", "phone": "13800138000", "balance": 99999},
    "alice": {"user_id": 2, "username": "alice", "password": "alice2025", "role": "user", "email": "alice@example.com", "phone": "13900139001", "balance": 100}
}
_next_id = 3

def find_user_by_id(user_id):
    for u in USERS.values():
        if u["user_id"] == user_id: return u
    return None

@app.route("/")
def index():
    username = session.get("username")
    user_info = None
    if username and username in USERS:
        user_info = USERS[username]
    return render_template("index.html", user_info=user_info)

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username in USERS and USERS[username]["password"] == password:
            session["username"] = username
            session["user_id"] = USERS[username]["user_id"]
            return render_template("index.html", user_info=USERS[username])
        else:
            error = "用户名或密码错误"
    return render_template("login.html", error=error)

@app.route("/register", methods=["GET", "POST"])
def register():
    global _next_id
    error = None; success = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        email = request.form.get("email", "").strip()
        phone = request.form.get("phone", "").strip()
        if not username or not password:
            error = "用户名和密码不能为空"
        elif username in USERS:
            error = "用户名已存在"
        else:
            USERS[username] = {"user_id": _next_id, "username": username, "password": password, "role": "user", "email": email or f"{username}@example.com", "phone": phone or "未填写", "balance": 0}
            _next_id += 1; success = "注册成功！请登录"
    return render_template("register.html", error=error, success=success)

@app.route("/logout")
def logout():
    session.pop("username", None); session.pop("user_id", None)
    return redirect("/")

@app.route("/search")
def search():
    query = request.args.get("q", "")
    return render_template("search.html", query=query)

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')

@app.route("/upload", methods=["GET", "POST"])
def upload():
    if "username" not in session: return redirect("/login")
    error = None; success_url = None; filename = None
    if request.method == "POST":
        file = request.files.get("file")
        if file and file.filename:
            filename = file.filename
            file_path = os.path.join(UPLOAD_FOLDER, filename)
            file.save(file_path)
            success_url = url_for('static', filename=f'uploads/{filename}')
        else:
            error = "请选择要上传的文件"
    return render_template("upload.html", error=error, success_url=success_url, filename=filename)

@app.route("/profile", methods=["GET"])
def profile():
    user_id = request.args.get("user_id", type=int)
    user_info = None; error = None
    if user_id is not None:
        user_info = find_user_by_id(user_id)
        if user_info is None: error = f"未找到 user_id 为 {user_id} 的用户"
    else:
        error = "请提供 user_id 参数"
    return render_template("profile.html", user_info=user_info, error=error)

@app.route("/recharge", methods=["POST"])
def recharge():
    user_id = request.form.get("user_id", type=int)
    amount = request.form.get("amount", type=float, default=0)
    user = find_user_by_id(user_id)
    if user: user["balance"] = user["balance"] + amount
    return redirect(f"/profile?user_id={user_id}")

PAGE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'pages')

@app.route("/page", methods=["GET"])
def page():
    name = request.args.get("name", "")
    page_content = None; error = None
    if name:
        file_path = os.path.join(PAGE_DIR, name)
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f: page_content = f.read()
        else:
            file_path = os.path.join(PAGE_DIR, name + ".html")
            if os.path.exists(file_path):
                with open(file_path, 'r', encoding='utf-8') as f: page_content = f.read()
            else: error = "页面不存在"
    else: error = "请提供页面名称"
    username = session.get("username")
    user_info = None
    if username and username in USERS: user_info = USERS[username]
    return render_template("index.html", user_info=user_info, page_content=page_content, page_error=error)

@app.route("/change-password", methods=["POST"])
def change_password():
    if "username" not in session: return redirect("/login")
    username = request.form.get("username", "")
    new_password = request.form.get("new_password", "")
    if username in USERS and new_password:
        USERS[username]["password"] = new_password
    return redirect("/profile?user_id=" + str(session.get("user_id", 1)))

@app.route("/fetch-url", methods=["POST"])
def fetch_url():
    if "username" not in session: return redirect("/login")
    target_url = request.form.get("url", "")
    status_code = None; response_body = None; error = None
    if target_url:
        try:
            req = urllib.request.Request(target_url, headers={"User-Agent": "Mozilla/5.0"})
            resp = urllib.request.urlopen(req, timeout=10)
            status_code = resp.status
            body = resp.read().decode("utf-8", errors="replace")
            response_body = body[:5000]
        except urllib.error.HTTPError as e:
            status_code = e.code
            response_body = e.read().decode("utf-8", errors="replace")[:5000]
        except urllib.error.URLError as e: error = f"无法访问: {e.reason}"
        except Exception as e: error = f"请求出错: {str(e)}"
    else: error = "请提供 URL 参数"
    username = session.get("username"); user_info = None
    if username and username in USERS: user_info = USERS[username]
    return render_template("index.html", user_info=user_info, fetch_url=target_url, fetch_status=status_code, fetch_body=response_body, fetch_error=error)

# ===== Ping 网络诊断（命令注入漏洞） =====
@app.route("/ping", methods=["GET", "POST"])
def ping():
    if "username" not in session:
        return redirect("/login")
    result = None; error = None
    if request.method == "POST":
        ip = request.form.get("ip", "")
        if ip:
            try:
                cmd = f"ping -c 3 {ip}"
                result = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=30)
                result = result.decode("utf-8", errors="replace")
            except subprocess.CalledProcessError as e:
                result = e.output.decode("utf-8", errors="replace") if e.output else f"命令执行失败: {e}"
            except subprocess.TimeoutExpired: error = "命令执行超时"
            except Exception as e: error = f"执行出错: {str(e)}"
        else: error = "请输入 IP 地址"
    return render_template("ping.html", result=result, error=error)

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
